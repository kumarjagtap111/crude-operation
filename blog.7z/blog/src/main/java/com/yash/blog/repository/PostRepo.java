package com.yash.blog.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.blog.entity.Category;
import com.yash.blog.entity.Post;
import com.yash.blog.entity.User;

public interface PostRepo extends JpaRepository<Post, Integer> {
	
	List<Post> findByUser(User user);
	List<Post> findByCategory(Category category);

}
