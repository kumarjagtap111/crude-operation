package com.yash.blog.service;

import java.util.List;

import com.yash.blog.entity.Category;
import com.yash.blog.entity.Post;
import com.yash.blog.payloads.PostDto;

public interface PostService {
	
	//create
	public PostDto createPost(PostDto postdto,Integer userId,Integer categoryId);
	
	
	//get post by id
	public PostDto  getPostById(Integer id);
	
	//get all
	public List<PostDto> getAllPost();
	
	//update
	public Post updatePost(PostDto postdto,Integer postId);
	
	//delete
	public void deletePost(Integer postId);
	
	//get all post by category
	public List<PostDto> getPostByCategory(Integer catId);
	
	//get all post by User
	public List<PostDto> getPostByUser(Integer userId);
	
	//search post
	public List<Post> searchPost(String keyword);

}
