package com.yash.blog.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.yash.blog.entity.User;
import com.yash.blog.payloads.UserDto;


public interface UserService {
	
  UserDto createUser(UserDto user);
  UserDto updateUser(UserDto user,Integer userId);
  UserDto getUserById(Integer userid);
  List<UserDto> getAllUser();
  void deleteUser(Integer userId);

}
