package com.yash.blog.serviceImpl;

import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.blog.entity.Category;
import com.yash.blog.entity.Post;
import com.yash.blog.entity.User;
import com.yash.blog.exception.ResourceNotFoundException;
import com.yash.blog.payloads.PostDto;
import com.yash.blog.repository.CategoryRepo;
import com.yash.blog.repository.PostRepo;
import com.yash.blog.repository.UserRepo;
import com.yash.blog.service.PostService;

@Service
public class PostServiceImpl implements PostService {
	
	@Autowired
	private PostRepo postrepo;
	
	@Autowired
	private ModelMapper modelmapper;
	@Autowired
	private UserRepo userrepo;
	@Autowired
	private CategoryRepo categoryrepo;

	@Override
	public PostDto createPost(PostDto postdto, Integer userId, Integer categoryId) {
		
		User user = this.userrepo.findById(userId).orElseThrow(()->new ResourceNotFoundException("User", "user id", userId));
		Category category = this.categoryrepo.findById(categoryId).orElseThrow(()->new ResourceNotFoundException("category", "category id", categoryId));
		Post post = this.modelmapper.map(postdto, Post.class);
		post.setImageName("default.png");
		post.setAddDate(new Date());
		post.setUser(user);
		post.setCategory(category);
		Post newpost = this.postrepo.save(post);
		return this.modelmapper.map(newpost, PostDto.class);
	}

	@Override
	public PostDto getPostById(Integer id) {
		Post post = this.postrepo.findById(id).orElseThrow(()-> new
		ResourceNotFoundException("Post","post id",id));
		return this.modelmapper.map(post,PostDto.class);
	}

	

	@Override
	public Post updatePost(PostDto postdto, Integer postId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deletePost(Integer postId) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<PostDto> getPostByCategory(Integer catId) {
		Category cat = this.categoryrepo.findById(catId).orElseThrow(()->new ResourceNotFoundException("category", "category id", catId));
		List<Post> posts = this.postrepo.findByCategory(cat);
	    List<PostDto> postdtos = posts.stream().map((post)->this.modelmapper.map(post, PostDto.class)).collect(Collectors.toList());
	  return postdtos;
	}

	@Override
	public List<PostDto> getPostByUser(Integer userId) {
	    
		  User user = this.userrepo.findById(userId).orElseThrow(()->new ResourceNotFoundException("User","user id",userId));
		        List<Post> posts = this.postrepo.findByUser(user);
		   List<PostDto> postdtos = posts.stream().
		   map((post)->this.modelmapper.map(post, PostDto.class)).collect(Collectors.toList());
		              
		        return postdtos;
	}
	

	@Override
	public List<Post> searchPost(String keyword) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<PostDto> getAllPost() {
		List<Post> postlist = this.postrepo.findAll();
		List<PostDto> postlistdto = postlist.stream()
		.map((post)->this.modelmapper.map(post, PostDto.class)).collect(Collectors.toList());
		
		return postlistdto;
	}

}
