package com.yash.blog.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.blog.payloads.ApiResponce;
import com.yash.blog.payloads.CategoryDto;
import com.yash.blog.service.CategoryService;

@RestController
@RequestMapping("api/category")
public class CategoryController {
	
	@Autowired
	private CategoryService catservice;
	
	//create
	
	@PostMapping("/create")
	public ResponseEntity<CategoryDto> createCategory(@RequestBody CategoryDto categorydto){
		
	   CategoryDto newcategory = this.catservice.createCategory(categorydto);
	   return new ResponseEntity<>(newcategory,HttpStatus.CREATED);
	}
	
	//getbyid
	
	@GetMapping("/getbyid/{id}")
	public ResponseEntity<CategoryDto> getCategoryById(@PathVariable int id){
		
		CategoryDto categoryById = this.catservice.getCategoryById(id);
		return new ResponseEntity<>(categoryById,HttpStatus.OK);
	}
	
	//getall
	
	@GetMapping("/getall")
	public ResponseEntity<List<CategoryDto>> getAllCategory(){
		
		List<CategoryDto> allCategory = this.catservice.getAllCategory();
		return new ResponseEntity<> (allCategory,HttpStatus.OK); 
	}
	
	//update
	
	@PutMapping("/update/{id}")
	public ResponseEntity<CategoryDto> updateCategory(@PathVariable int id,@RequestBody CategoryDto catdto){
		
		CategoryDto updateCategory = this.catservice.updateCategory(catdto, id);
		return new ResponseEntity<>(updateCategory,HttpStatus.OK);
		
	}
	
	//delete
	@DeleteMapping("/delete/{id}")
	public ResponseEntity<ApiResponce> deleteCategoryById(@PathVariable int id){
		
		this.catservice.deleteCategory(id);
		
		return new  ResponseEntity(new ApiResponce("user deleted successfully",true),HttpStatus.OK );
	}
	

}
