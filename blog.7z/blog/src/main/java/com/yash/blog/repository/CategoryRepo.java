package com.yash.blog.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.blog.entity.Category;

public interface CategoryRepo extends JpaRepository<Category, Integer> {

}
