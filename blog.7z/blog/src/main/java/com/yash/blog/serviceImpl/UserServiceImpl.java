package com.yash.blog.serviceImpl;

import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.blog.entity.User;
import com.yash.blog.exception.ResourceNotFoundException;
import com.yash.blog.payloads.UserDto;
import com.yash.blog.repository.UserRepo;
import com.yash.blog.service.UserService;

@Service
public class UserServiceImpl implements UserService {
    
	@Autowired
	private UserRepo userrepo;
	
	@Autowired
	private ModelMapper modelMapper;
	
	@Override
	public UserDto createUser(UserDto userDto) {
	    User user = this.dtoToUser(userDto);
	    User saveuser = this.userrepo.save(user);
		return this.userToDto(saveuser);
	}

	@Override
	public UserDto updateUser(UserDto userDto, Integer userId) {
		User user = this.userrepo.findById(userId).orElseThrow(()->
		new ResourceNotFoundException("user","id",userId));
		
		user.setName(userDto.getName());
		user.setEmail(userDto.getEmail());
		user.setPassword(userDto.getPassword());
		user.setAbout(userDto.getAbout());
	    User updatedUser =  this.userrepo.save(user);

		 UserDto dtoUser1 = this.userToDto(updatedUser);
		return dtoUser1;
				
	}

	@Override
	public UserDto getUserById(Integer userid) {
		
		User user = this.userrepo.findById(userid).orElseThrow(()->
		new ResourceNotFoundException("User","id", userid));
		
		return this.userToDto(user);
	}

	@Override
	public List<UserDto> getAllUser() {
     
		List<User> users = this.userrepo.findAll();
		
		List<UserDto> userlist = users.stream().
				map(user->this.userToDto(user)).collect(Collectors.toList());
		
		return userlist;
	}

	@Override
	public void deleteUser(Integer userId) {
		
		User user = this.userrepo.findById(userId).orElseThrow(()->
		new ResourceNotFoundException("User", "id", userId));
		
		this.userrepo.delete(user);
	}
	
	private User dtoToUser(UserDto userdto) {
		
		User user = this.modelMapper.map(userdto, User.class);
//		user.setId(userdto.getId());
//		user.setName(userdto.getName());
//		user.setEmail(userdto.getEmail());
//		user.setPassword(userdto.getPassword());
//		user.setAbout(userdto.getAbout());
		return user;
	}
	
	public UserDto userToDto(User user) {
	
		UserDto userDto = this.modelMapper.map(user, UserDto.class);
//		userDto.setId(user.getId());
//		userDto.setName(user.getName());
//		userDto.setEmail(user.getEmail());
//		userDto.setAbout(user.getAbout());
//		userDto.setPassword(user.getPassword());
		return userDto;
		
	}

}
