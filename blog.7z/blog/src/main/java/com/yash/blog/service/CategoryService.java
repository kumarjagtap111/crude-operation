package com.yash.blog.service;

import java.util.List;

import com.yash.blog.entity.Category;
import com.yash.blog.payloads.CategoryDto;

public interface CategoryService {
	
	//create
	public CategoryDto createCategory(CategoryDto category);
	
	//update
	public CategoryDto updateCategory(CategoryDto categorydto,Integer id);
	
	//delete
	public void deleteCategory(Integer id);
	
	//get
	public CategoryDto getCategoryById(Integer id);
	
	//getAll
	public List<CategoryDto> getAllCategory();
	
	

}
