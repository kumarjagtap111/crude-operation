package com.yash.blog.controller;

import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.blog.payloads.ApiResponce;
import com.yash.blog.payloads.UserDto;
import com.yash.blog.service.UserService;

@RestController()
@RequestMapping("/api/user")
public class UserController {
	
	@Autowired
	private UserService userservice;
	
	//POST- create user
	@PostMapping("/createuser")
	public ResponseEntity<UserDto> createUser(@Valid @RequestBody UserDto userdto){
		
		UserDto createUserDto = this.userservice.createUser(userdto);
		return new ResponseEntity<>(createUserDto,HttpStatus.CREATED);
	}
	
	

	
	//PUT- update user
	
	@PutMapping("/updateuser/{id}")
	public ResponseEntity<UserDto> updateUser(@Valid @RequestBody UserDto userdto,@PathVariable int id){
		
		UserDto updateuser =  this.userservice.updateUser(userdto, id);
		return new ResponseEntity<>(updateuser,HttpStatus.OK);
		
	}
	
	//DELETE - delete user
	
	@DeleteMapping("/deleteuser/{id}")
	public ResponseEntity<ApiResponce> deleteUser(@PathVariable int id){
		
		this.userservice.deleteUser(id);
		return new ResponseEntity(new ApiResponce("user deleted successfully",true),HttpStatus.OK);
	}
	
	//GET -all user
	
	@GetMapping("/getalluser")
	public ResponseEntity<List<UserDto>> getAllUser(){
		
		List<UserDto> userlist =  this.userservice.getAllUser();
		return new ResponseEntity<>(userlist,HttpStatus.OK);
	}
	
	// GET - user by ID
	
	@GetMapping("/getuserbyid/{id}")
	public ResponseEntity<UserDto> getUserById(@PathVariable int id){
		
		UserDto user = userservice.getUserById(id);
		
		return new ResponseEntity<>(user,HttpStatus.OK);
		
	}
	
	


}
