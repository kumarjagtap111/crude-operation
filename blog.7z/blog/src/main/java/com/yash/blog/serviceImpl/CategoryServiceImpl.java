package com.yash.blog.serviceImpl;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.blog.entity.Category;
import com.yash.blog.entity.User;
import com.yash.blog.exception.ResourceNotFoundException;
import com.yash.blog.payloads.CategoryDto;
import com.yash.blog.repository.CategoryRepo;
import com.yash.blog.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService{
	
	@Autowired
	private CategoryRepo categoryrepo;
	
	@Autowired
	private ModelMapper modelmapper;
	
	

	@Override
	public CategoryDto createCategory(CategoryDto categorydto) {
		
		Category category = this.dtoToCategory(categorydto);
		Category newCategory = this.categoryrepo.save(category);
		return this.categoryToDto(newCategory);
		
	}
   //update
	@Override
	public CategoryDto updateCategory(CategoryDto categorydto, Integer id) {
		
		Category category = this.categoryrepo.findById(id).orElseThrow(()->
		new ResourceNotFoundException("category","id",id));
		
		category.setCategoryTitle(categorydto.getCategoryTitle());
		category.setCategoryDescription(categorydto.getCategoryDescription());
		
		Category updateCategory = this.categoryrepo.save(category);
		
		return this.categoryToDto(updateCategory);
	}

	@Override
	public void deleteCategory(Integer id) {
		Category cat = this.categoryrepo.findById(id).orElseThrow(()->
		new ResourceNotFoundException("category","id",id));
		this.categoryrepo.delete(cat);
	}

	@Override
	public CategoryDto getCategoryById(Integer id) {
		Category cat = this.categoryrepo.findById(id).orElseThrow(()->
		               new ResourceNotFoundException("category","id",id));
				
		return this.categoryToDto(cat);
	}

	@Override
	public List<CategoryDto> getAllCategory() {
		List<Category> categorylist = this.categoryrepo.findAll();
		
		List<CategoryDto> collect = categorylist.stream().map(cat->this.categoryToDto(cat)).collect(Collectors.toList());
		
		return collect;
	}
	
	
	public Category dtoToCategory(CategoryDto categorydto) {
		
		Category category = this.modelmapper.map(categorydto, Category.class);
		return category;
	}
	
	public CategoryDto categoryToDto(Category category) {
		
		CategoryDto categorydto = this.modelmapper.map(category, CategoryDto.class);
		return categorydto;
	}
	
	

}
