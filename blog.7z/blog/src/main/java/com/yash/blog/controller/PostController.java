package com.yash.blog.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.blog.entity.Post;
import com.yash.blog.payloads.PostDto;
import com.yash.blog.service.PostService;

@RestController
@RequestMapping("api/")
public class PostController {
	
  @Autowired
  private PostService postservice;
  
  //create
  @PostMapping("/user/{userId}/category/{categoryId}/posts")
  public ResponseEntity<PostDto> createPost(@RequestBody PostDto postDto,@PathVariable Integer userId,@PathVariable Integer categoryId){
	  
	  PostDto createPost = this.postservice.createPost(postDto, userId, categoryId);
	 return new ResponseEntity<PostDto>(createPost,HttpStatus.CREATED);
	 
 }
  
  //get post by useridl
     @GetMapping("/user/{userid}/posts")
	 public ResponseEntity<List<PostDto>>  getPostByUser(@PathVariable Integer userid){
    	 
    	 List<PostDto> postByUser = this.postservice.getPostByUser(userid);
    	 
    	 return new ResponseEntity<>(postByUser,HttpStatus.OK);
    	 
     }
    	 //get post by category id
    	 @GetMapping("/category/{categoryid}/posts")
    	 public ResponseEntity<List<PostDto>> getPostByCategory(@PathVariable Integer categoryid){
    		 
    		 List<PostDto> postByCategory = this.postservice.getPostByCategory(categoryid);
    		 return new ResponseEntity<>(postByCategory,HttpStatus.OK);
    		 
    	 }
    	 
    	 //get all post
    	 
    	 @GetMapping("/postlist")
    	 public ResponseEntity<List<PostDto>> getAllPost(){
    		 
    		 List<PostDto> allPost = this.postservice.getAllPost();
    		return new ResponseEntity<>(allPost,HttpStatus.OK);
    	 }
    	 
    	 //get post by id
    	 @GetMapping("/post/{id}")
    	 public ResponseEntity<PostDto> getPostById(@PathVariable Integer id){
    		 
    		 PostDto postById = this.postservice.getPostById(id);
    		 return new ResponseEntity<>(postById,HttpStatus.OK);
    		 
    	 }
    	 
    	 
    	 
    	 
    	 
		 
	 
     
     

}
