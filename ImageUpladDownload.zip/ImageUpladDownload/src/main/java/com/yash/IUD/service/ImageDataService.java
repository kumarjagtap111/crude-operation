package com.yash.IUD.service;

import java.io.IOException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.yash.IUD.entity.ImageData;
import com.yash.IUD.repo.ImageDataRepo;
import com.yash.IUD.utility.ImageUtils;

@Service
public class ImageDataService {
	
	@Autowired
	private ImageDataRepo repo;
	
	
	public String uploadImage(MultipartFile file) throws IOException {
		
		ImageData imageData = repo.save(ImageData.builder()
				.name(file.getOriginalFilename())
				.type(file.getContentType())
				 .imagedata(ImageUtils.compressImage(file.getBytes())).build());
		
		if(imageData!=null) {
			
			return "file uploaded successfully "+file.getOriginalFilename();
			
		}
		return null;
		
	}
	
	public byte[] downloadImage(String imagename) {
		
		Optional<ImageData> dbImageData = repo.findByName(imagename);
		byte[] decompressImage = ImageUtils.decompressImage(dbImageData.get().getImagedata());
		return decompressImage;
	}

}
