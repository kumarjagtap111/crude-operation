package com.yash.IUD.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.IUD.entity.ImageData;

public interface ImageDataRepo extends JpaRepository<ImageData, Integer> {

	Optional<ImageData> findByName(String fileName);
	
}
