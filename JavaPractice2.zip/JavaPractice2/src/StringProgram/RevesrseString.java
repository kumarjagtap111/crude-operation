package StringProgram;

public class RevesrseString {
	
	public static void main(String[] args) {
		
		String str = "welcome";
		
		/*  1. Using toCharArray
		 * char string[] = str.toCharArray(); System.out.println(string.length);
		 * 
		 * for(int i=string.length-1; i>=0 ;i--) {
		 * 
		 * System.out.print(string[i]); }
		 */
		
		//2. without using tochar array
		
		String str1=" ";
		
		for(int i=str.length()-1;i>=0; i--) {
			
			str1= str1+str.charAt(i);
			
		}
		
		System.out.println(str1);
		
	}

}
