package StringProgram;

import java.util.Arrays;
import java.util.HashMap;

public class CharacterOccuranceByJava8 {
	
	public static void main(String[] args) {
		
		
		String str = "yash technology yash";
		
		HashMap<String, Integer> map = new HashMap<>();
		
		Arrays.asList(str.split(" ")).forEach(s->map.put(s, map.getOrDefault(s,0)+1));
		map.forEach((k,v)->System.out.println(k+" "+v));
		
	}

}
