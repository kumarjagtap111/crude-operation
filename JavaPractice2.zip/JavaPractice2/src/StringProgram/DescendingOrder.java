package StringProgram;

import java.util.Arrays;
import java.util.Collections;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class DescendingOrder {
	
	public static void main(String[] args) {
		
		
		int arr[] = {7,9,3,4,2,1};
		
		Stream<Integer> stream = Arrays.stream(arr).boxed();
		stream.sorted(Collections.reverseOrder())
		.collect(Collectors.toList()).forEach(System.out::println);
 		
	}

}
