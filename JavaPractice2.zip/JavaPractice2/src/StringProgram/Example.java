package StringProgram;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

public class Example {
	
	public static void main(String[] args) {
		
		
		List<Integer> list = Arrays.asList(1,2,3,4,4,3,2);
		
		Optional<Integer> findFirst = list.stream().sorted(Collections.reverseOrder()).distinct().skip(1).findFirst();
		System.out.println(findFirst);
	}
	
	

}
