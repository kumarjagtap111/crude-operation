package StringProgram;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EmployeeOperation {
	
	public static void main(String[] args) {
		
		
		List<Employee> employee = new ArrayList<>();
		
		employee.add(new Employee(1,"sachin","pune",29));
		employee.add(new Employee(2,"kumar","pune",31));
		employee.add(new Employee(3,"rahul","nashik",29));
		employee.add(new Employee(4,"ram","mumbai",29));
		employee.add(new Employee(5,"raj","mumbai",29));
		employee.add(new Employee(6,"gaja","latur",29));
		
		
		
		
		Map<String, Long> collect = employee.stream()
		.collect(Collectors.groupingBy(Employee::getCity,Collectors.counting()));
		System.out.println(collect);
		
		
		
		
		
		
	}

}
