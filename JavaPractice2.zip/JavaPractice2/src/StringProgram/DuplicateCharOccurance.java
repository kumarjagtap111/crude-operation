package StringProgram;

public class DuplicateCharOccurance {
	
	public static void main(String[] args) {
		
		
		String string = "welcome in java development ";
		 System.out.println("original string is:  "+string);
		 System.out.println("Duplicate character are: ");
		char str[] = string.toCharArray();
		int count;
		
		for(int i=0;i<str.length;i++) {
			
			count=1;
			
			for(int j=i+1;j<str.length;j++) {
				
				if(str[i]==str[j] && str[j]!=' ') {  //space not considered
					
					count++;
					str[j]=' ';  //assigned 
					
				}
			}
			
			if(count>1 && str[i]!=' ') {
				
				System.out.print(str[i]+",");
			}
			
			
		}
		System.out.println();
		System.out.println(str);
		
		
		
		
		
	}

}
