package Interface;

public class Child extends Parent{
	
	public static void m1() {
		
		
		System.out.println("child m1");
	}
	
	
	public static void main(String[] args) {
		
		
		Child p = new Child();
		
		//p.m1();
		
		Parent parent = new Child();
		parent.m1();
	}

}
