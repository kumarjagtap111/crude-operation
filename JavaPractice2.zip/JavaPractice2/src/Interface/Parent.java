package Interface;

public  class Parent {
	
	public static void m1() {
		
		System.out.println("parent m1");
	}

}
