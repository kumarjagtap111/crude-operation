package Java8Program;

import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class AscendingOrder {
	
	public static void main(String[] args) {
		
		List<Integer> list = Arrays.asList(7,9,3,5,4,2,1,7);
		
		System.out.println("Ascending Order");
		List<Integer> collect = list.stream().sorted().collect(Collectors.toList());
		System.out.println(collect);
		
      	Integer number = list.stream().sorted(Comparator.reverseOrder()).distinct().skip(1).findFirst().get();
		System.out.println("second highest number: "+number);
		
	}

}
