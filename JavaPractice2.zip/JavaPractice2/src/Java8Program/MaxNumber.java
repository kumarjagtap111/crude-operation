package Java8Program;

import java.util.Arrays;
import java.util.List;

public class MaxNumber {
	
	public static void main(String[] args) {
		
		
		List<Integer> list = Arrays.asList(4,7,9,1,2,3);
		
		Integer integer = list.stream().max(Integer::compare).get();
		
		System.out.println(integer);
	}

}
