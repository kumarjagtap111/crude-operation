package Java8Program;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class EmployeeOperation {
	
	public static void main(String[] args) {
		
		List<Employee> emp = new ArrayList<>();
		
		emp.add(new Employee(1,"kumar","java developer",31,60000));
		emp.add(new Employee(2,"tushar","Python developer",29,70000));
		emp.add(new Employee(3,"ram","tester",25,45000));
		emp.add(new Employee(4,"rahul","java developer",32,40000));
		emp.add(new Employee(5,"raj","Python developer",29,49000));
		emp.add(new Employee(6,"Om","tester",28,80000));
		
		
		//1. department list
		
		List<String> collect = emp.stream().map(dept->dept.getDept()).distinct().collect(Collectors.toList());
		System.out.println(collect);
		
		
		//2. Highest salary
		
		Integer salary = emp.stream().map(sal->sal.getSalary()).max(Integer::compare).get();
		System.out.println("highest salary: "+salary);
		
		//3. second Highest salary
		
		
		emp.stream().map(sal->sal.getSalary()).sorted(Comparator.reverseOrder()).distinct().skip(1).findFirst().get();
		//System.out.println("second highest salary : "+secondhighest);
		
		
		//4. Age is above 30 and salary less than 50 
		System.out.println("Employee name");
		emp.stream().filter(age->age.getAge()>30 && age.getSalary()<50000).map(name->name.getName())
				.collect(Collectors.toList()).forEach(System.out::println);
		
		
		
		
		
		
	}

}
