package StreamApiMethods;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class EmployeeOperations {
	
	public static void main(String[] args) {
		
		
		List<Employee> list = new ArrayList<>();
		
		list.add(new Employee(1,"kumar","pune",75000,32));
		list.add(new Employee(2,"sachin","mumbai",80000,30));
		list.add(new Employee(3,"kiran","akola",40000,29));
		list.add(new Employee(4,"raj","nashik",51000,28));
		list.add(new Employee(5,"ram","pune",45000,52));
		
		
		System.out.println("emp with condition");
		
		list.stream().filter((e)->e.getCity().equals("pune") && e.getSalary()>50000)
		.collect(Collectors.toList()).forEach(System.out::println);
		
		System.out.println("highest salary :");
		
		Integer highsal = list.stream().map(e->e.getSalary()).max(Integer::compare).get();
		
		System.out.println(highsal);
		//1. list of employee name;
		
		list.stream().map(name->name.getName()).collect(Collectors.toList()).forEach(System.out::println);
		
		//2. list of city working employees
		
		list.stream().map(Employee::getCity).distinct().collect(Collectors.toList()).forEach(System.out::println);
		
		//3 print employee whose salary more than 50k and age more than 30
		System.out.println();
		
		list.stream().filter(sal->sal.getSalary()>50000 && sal.getAge()>30).map(name->name.getName()).collect(Collectors.toList()).forEach(System.out::println);
		
		
		// city wise employee count
		System.out.println();
		
		Map<String, Long> collect = list.stream().collect(Collectors.groupingBy(Employee::getCity,Collectors.counting()));
		System.out.println(collect);
		
		// employee start with 'k'
		System.out.println("start with initial 'k' ");
		
		list.stream().filter(name->name.getName().startsWith("k")).map(Employee::getName). collect(Collectors.toList()).forEach(System.out::println);	
		
		// convert all letters in uppercase
		System.out.println("upper case: ");
		
		list.stream().map(name->name.getName().toUpperCase()).collect(Collectors.toList()).forEach(System.out::println);
		
		
		//count number of employee
		
		long count = list.stream().count();
		System.out.println("number of employee: "+count);
		
		//sum of salary
		
		Integer collect2 = list.stream().collect(Collectors.summingInt(sal->sal.getSalary()));
		System.out.println("sum of salary: "+collect2);
		
		Map<String, Long> collect3 = list.stream().collect(Collectors.groupingBy(Employee::getCity,Collectors.counting()));
		System.out.println(collect3);
		
		
		System.out.println();
		list.stream().filter(name->name.getName().equalsIgnoreCase("Kumar")).map(sal->sal.getSalary()).collect(Collectors.toList()).forEach(System.out::println);
		
		
	}

}

