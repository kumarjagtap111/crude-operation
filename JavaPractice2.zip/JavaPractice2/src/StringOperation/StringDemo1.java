package StringOperation;

public class StringDemo1 {
	
	
	public static void main(String[] args) {
		
		String s1 = new String("kumar");
		String s2 = new String("kumar");
		
		System.out.println(s1==s2);//false - check reference or memory address
		System.out.println(s1.equals(s2));//true - check content
		
		String s3="kumar";
		
		System.out.println(s1.equals(s3));//true - content
		System.out.println(s1==s3);//false - address
		System.out.println(s1==s2);//false
		
		String s4="kumar";
		System.out.println(s3==s4);//true
		
	}

}
