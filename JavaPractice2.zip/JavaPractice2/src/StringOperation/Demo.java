package StringOperation;

public class Demo {
	
	public static void main(String[] args) {
		
		String s1 = "welcome";
		System.out.println(s1);
		s1="kumar";
		System.out.println(s1);
	}

}
