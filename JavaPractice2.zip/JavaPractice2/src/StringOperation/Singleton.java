package StringOperation;

public class Singleton {
	
	private static Singleton s1=null;//lazy initilization
	
	private Singleton() {
		
	}
	
	public static  synchronized Singleton getInstance() {
		
		if(s1==null) {
			
			s1 = new Singleton();
		}
		
		return s1;
	}
	
	
	public static void main(String[] args) {
		
		Singleton obj1 = Singleton.getInstance();
		
		Singleton obj2 = Singleton.getInstance();
		
		System.out.println(obj1.hashCode());
		System.out.println(obj2.hashCode());
		
	}
	
	

}
