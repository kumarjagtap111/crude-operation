package StringOperation;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class StreamApidemo {
	
	public static void main(String[] args) {
		
		
		//List<String> list = Arrays.asList("kumar","anil","sachin","abhi");
		
		
		//list.stream().collect(Collectors.toList()).forEach(System.out::println);
		
		//list.stream().sorted().forEach((name)->System.out.println(name));
		//System.out.println(collect);
		
		List<String> list = new ArrayList<>();
		//list.add("sachin");
		//list.add("abc");
		//list.add("xyz");
		
		System.out.println(list.size());
		
		
		/*
		 * for(String i: list ) {
		 * 
		 * System.out.println(i); }
		 */
		
		
	}

}
