package com.yash.pms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductManaementSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductManaementSystemApplication.class, args);
	}

}
