package com.yash.pms.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.pms.entity.Customer;
import com.yash.pms.service.CustomerService;

@RestController
public class CustomerController {
	
	@Autowired
	private CustomerService custservice;
	
	@PostMapping("/addcust")
	public ResponseEntity<Customer> createEmployee(@RequestBody Customer cust){
		
		Customer addCustomer = custservice.addCustomer(cust);
		
		return new ResponseEntity(addCustomer,HttpStatus.CREATED);
		
	}
	
	@GetMapping("/getallcust")
	public ResponseEntity<List<Customer>> getAllCustomer(){
		
		List<Customer> listOfCustomer = custservice.listOfCustomer();
		return new ResponseEntity(listOfCustomer,HttpStatus.OK);
		
	}
	
	@DeleteMapping("/deletecust/{custId}")
	public ResponseEntity<Customer> deleteCustById(@PathVariable("custId") Integer custId) {
		
		custservice.deleteCustById(custId);
		return new ResponseEntity("employee deleted successfully",HttpStatus.OK);
		
		
	}
	
	@PutMapping("/updatecust/{custId}")
	public ResponseEntity<Customer> updateCustById(@PathVariable("custId") Integer custId,@RequestBody Customer cust){
		
		Customer updateCustomer = custservice.updateCustomer(custId, cust);
		
		return new ResponseEntity(updateCustomer,HttpStatus.OK);
		
		
		
	}
	
	

}
