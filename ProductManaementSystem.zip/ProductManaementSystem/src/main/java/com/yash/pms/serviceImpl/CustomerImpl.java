package com.yash.pms.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.yash.pms.entity.Customer;
import com.yash.pms.exceptions.ResourceNotFoundException;
import com.yash.pms.repo.CustomerRepo;
import com.yash.pms.service.CustomerService;

@Service
public class CustomerImpl implements CustomerService {
	
	@Autowired
	private CustomerRepo custrepo;

	@Override
	public Customer addCustomer(Customer cust) {
		
		Customer customer = custrepo.save(cust);
		return customer;
		
		
	}

	@Override
	public List<Customer> listOfCustomer() {
		
		List<Customer> findAll = custrepo.findAll();
		
		return findAll;
	}

	@Override
	public void deleteCustById(Integer custId) {
		
		Customer customer = custrepo.findById(custId).orElseThrow(()->new ResourceNotFoundException("customer","id", custId));
		custrepo.delete(customer);
		
	}

	@Override
	public Customer updateCustomer(Integer custId, Customer cust) {
		
		Customer c1 = custrepo.findById(custId).orElseThrow(()->new ResourceNotFoundException("customer", "id", custId));
		c1.setCustName(cust.getCustName());
		c1.setCity(cust.getCity());
		Customer updatedcust = custrepo.save(c1);
		
		
		return updatedcust;
	}
	
	

}
