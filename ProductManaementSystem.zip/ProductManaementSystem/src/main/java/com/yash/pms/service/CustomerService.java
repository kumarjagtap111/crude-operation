package com.yash.pms.service;

import java.util.List;

import com.yash.pms.entity.Customer;

public interface CustomerService {
	
	//1. Add customer
	
	public Customer addCustomer(Customer cust);
	
	//2. get all employee
	
	public List<Customer> listOfCustomer(); 
	
	//3.delete employee by Id
	
	public void deleteCustById(Integer custId);
	
	//4. update employee
	
	public Customer updateCustomer(Integer custId, Customer cust);

}
