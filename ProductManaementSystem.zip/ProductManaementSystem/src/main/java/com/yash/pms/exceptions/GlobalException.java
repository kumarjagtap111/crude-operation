package com.yash.pms.exceptions;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.yash.pms.API.ApiResponce;

@RestControllerAdvice
public class GlobalException {
	
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<ApiResponce> resourceNotFound(ResourceNotFoundException ex){
		
		
		String message = ex.getMessage();
		ApiResponce apiresponse = new ApiResponce(message,false);
		
		return new ResponseEntity(apiresponse,HttpStatus.NOT_FOUND);
		
		
	}

}
