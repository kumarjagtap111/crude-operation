package com.yash.pms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductManaementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
