package com.yash.pms.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.pms.model.Person;
import com.yash.pms.model.Pet;

public interface PetRepo extends JpaRepository<Pet, Integer> {
	
	

}
