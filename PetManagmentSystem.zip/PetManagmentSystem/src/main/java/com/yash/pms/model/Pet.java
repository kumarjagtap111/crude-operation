package com.yash.pms.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

@Entity
public class Pet {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int petId;
	
	private String petName;
	
	@ManyToOne
	@JoinColumn(name="id")
	private Person person;

	public int getPetId() {
		return petId;
	}

	public void setPetId(int petId) {
		this.petId = petId;
	}

	public String getPetName() {
		return petName;
	}

	public void setPetName(String petName) {
		this.petName = petName;
	}

	public Person getPerson() {
		return person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

	public Pet(int petId, String petName, Person person) {
		super();
		this.petId = petId;
		this.petName = petName;
		this.person = person;
	}

	public Pet() {
		super();
		// TODO Auto-generated constructor stub
	}

		
	
}
