package com.yash.pms.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.pms.model.Person;
import com.yash.pms.model.Pet;

public interface PersonRepo extends JpaRepository<Person, Integer> {
	
	Person findByPet(Pet pet);

}
