package com.yash.pms.service;

import java.util.List;

import com.yash.pms.model.Person;
import com.yash.pms.model.Pet;

public interface PetService {
	
	
	
	
	
	

}
