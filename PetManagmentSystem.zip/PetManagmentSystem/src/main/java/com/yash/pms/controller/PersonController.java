package com.yash.pms.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.pms.model.Person;
import com.yash.pms.model.Pet;
import com.yash.pms.repo.PetRepo;
import com.yash.pms.serviceImpl.PersonServiceImpl;

@RestController
public class PersonController {
	
  @Autowired	
  private PersonServiceImpl personservice;
  
  @Autowired
  private PetRepo petrepo;
  
  @PostMapping("/createperson")
  public ResponseEntity<Person> createPerson(@RequestBody Person person){
	  
	  Person createPerson = personservice.createPerson(person);
	  
	  return new ResponseEntity(createPerson,HttpStatus.CREATED);
	  
  }
  
  @PostMapping("/createpet/{id}")
  public ResponseEntity<Pet> createPet(@PathVariable Integer id,@RequestBody Pet pet){
	  
	  Pet createPet = personservice.createPet(id, pet);
	  
	  return new ResponseEntity(createPet,HttpStatus.OK);
	  
	  
  }
  
  @GetMapping("/getallperson")
   public ResponseEntity<List<Person>> getAllPerson(){
  
	   List<Person> allPerson = personservice.getAllPerson();
	   return new ResponseEntity(allPerson,HttpStatus.OK);
  

}
  @GetMapping("/person/{id}")
  public ResponseEntity<List<Pet>> getPersonbyId(@PathVariable(value="id") Integer id){
	  
	  Person personById = personservice.getPersonById(id);
	  List<Pet> petlist = new ArrayList<Pet>();
	  
	  petlist.addAll(personById.getPet());
	  
	  return new ResponseEntity(petlist,HttpStatus.OK);
	  
	}
  
  @GetMapping("/pet/{petId}/person")
  public ResponseEntity getPersonByPet(@PathVariable(value="petId") Integer petId){
	  
	  String person = personservice.getPersonByPetId(petId);
	  
	  return new ResponseEntity(person,HttpStatus.OK);
	  
  }
  
  @GetMapping("/{petId}/owner")
  public ResponseEntity<String> getPersonNameByPetId(@PathVariable Integer petId) {
  return petrepo.findById(petId)
  .map(Pet::getPerson)
  .map(Person::getName)
  .map(ResponseEntity::ok)
  .orElse(ResponseEntity.notFound().build());
  }
  
  
  
  
}