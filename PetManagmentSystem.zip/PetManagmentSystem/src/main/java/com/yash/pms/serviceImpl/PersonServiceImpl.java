package com.yash.pms.serviceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.pms.model.Person;
import com.yash.pms.model.Pet;
import com.yash.pms.repo.PersonRepo;
import com.yash.pms.repo.PetRepo;
import com.yash.pms.service.PersonService;

@Service
public class PersonServiceImpl implements PersonService {
	
	@Autowired
	private PersonRepo personrepo;
	
	@Autowired
	private PetRepo petrepo;

	@Override
	public Person createPerson(Person person) {
		
		Person newperson = personrepo.save(person);
		return newperson;
	}

	@Override
	public Pet createPet(int id,Pet pet) {
		
   Optional<Person> personid = personrepo.findById(id);
   
   Pet petobj = new Pet();
   List<Pet> petlist = new ArrayList<>();
   if(personid.isPresent()) {
	   
	   Person pobj = personid.get();
	   
	    petlist = pobj.getPet();
	   petobj.setPetId(pet.getPetId());
	   
	   petobj.setPetName(pet.getPetName());
	   petlist.add(petobj);
	   
	   pobj.setPet(petlist);
	   
	   personrepo.save(pobj);
  }
		
   return  pet;
		
		
	}

	@Override
	public List<Person> getAllPerson() {
		
		List<Person> findAll = personrepo.findAll();
		return findAll;
	}

	

	@Override
	public Person getPersonById(Integer id) {
		
		
	  return personrepo.findById(id).get();
	}

	@Override
	public String getPersonByPetId(Integer petId) {
		
		
		  Pet pet = petrepo.findById(petId).get();
		  
		  Person person = personrepo.findByPet(pet);
		  
		  return person.getName();
		 
		
		//petrepo.findById(petId).map(Pet::getPerson).
		
	}
	
	
	
	

	

	
	



}
