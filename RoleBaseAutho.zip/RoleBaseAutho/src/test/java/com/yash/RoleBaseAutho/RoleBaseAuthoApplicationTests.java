package com.yash.RoleBaseAutho;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoleBaseAuthoApplicationTests {

	@Test
	void contextLoads() {
	}

}
