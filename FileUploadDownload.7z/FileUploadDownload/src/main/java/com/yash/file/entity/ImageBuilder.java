package com.yash.file.entity;

import jakarta.persistence.Lob;

public class ImageBuilder {
	
	private int id;
	private String name;
	private String type;
	private byte[] imagedata;
	
	public ImageBuilder setId(int id) {
		this.id = id;
		return this;
	}
	public ImageBuilder setName(String name) {
		this.name = name;
		return this;
		
	}
	public ImageBuilder setType(String type) {
		this.type = type;
		return this;
	}
	public ImageBuilder setImagedata(byte[] imagedata) {
		this.imagedata = imagedata;
		return this;
	}
	
	public ImageData getImage() {
		
		return new ImageData(id,name,type,imagedata);
	}
	
	

}
