package com.yash.file.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.yash.file.entity.ImageBuilder;
import com.yash.file.entity.ImageData;
import com.yash.file.repo.ImageDataRepo;

@Service
public class ImageDataService {

	@Autowired
	private ImageDataRepo imagerepo;
	
	public String uploadImage(MultipartFile file) {
		
		
		ImageData imagedata =  imagerepo.save(new ImageBuilder().setName(file.getOriginalFilename())
		.setType(file.getContentType()).setImagedata(file.getBytes()));
		return "file uploaded";
	}
}
