package com.yash.file.repo;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.file.entity.ImageData;

public interface ImageDataRepo extends JpaRepository<ImageData, Integer> {
	
	 Optional<ImageData> findImageByName(String filename);

}
