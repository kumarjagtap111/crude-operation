package com.yash.file;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FileUploadDownloadApplicationTests {

	@Test
	void contextLoads() {
	}

}
