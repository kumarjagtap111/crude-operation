package com.yash.SLCE.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.yash.SLCE.Entity.City;
import com.yash.SLCE.Service.CityService;

@RestController
public class CityController {
	
	@Autowired
	private CityService cityservice;
	
	@PostMapping("/savecity")
	public ResponseEntity<City> saveCity(@RequestBody City city){
		
		City saveCity = cityservice.saveCity(city);
		return new ResponseEntity<>(saveCity,HttpStatus.CREATED);
	}
	
	@GetMapping("/getcity/{id}")
	public ResponseEntity<City> getCity(@PathVariable int id){
		
		City cityById = cityservice.getCityById(id);
		return new ResponseEntity<>(cityById,HttpStatus.OK);
		
	}
	
	

}
