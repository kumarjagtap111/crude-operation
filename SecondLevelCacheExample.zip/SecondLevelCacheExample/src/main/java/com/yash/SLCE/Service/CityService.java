package com.yash.SLCE.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yash.SLCE.Entity.City;
import com.yash.SLCE.Repo.CityRepo;

@Service
public class CityService {
	
	@Autowired
	private CityRepo cityrepo;
	
	public City getCityById(int id) {
		
		return cityrepo.findById(id).get();
		
	}
	
	public City saveCity(City city) {
		
		return cityrepo.save(city);
	}
	
	

}
