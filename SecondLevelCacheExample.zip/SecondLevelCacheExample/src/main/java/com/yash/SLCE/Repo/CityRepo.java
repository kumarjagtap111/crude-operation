package com.yash.SLCE.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.yash.SLCE.Entity.City;

public interface CityRepo extends JpaRepository<City, Integer> {

}
